/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50536
 Source Host           : localhost:3306
 Source Schema         : crm

 Target Server Type    : MySQL
 Target Server Version : 50536
 File Encoding         : 65001

 Date: 29/01/2023 17:06:27
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tbl_activity
-- ----------------------------
DROP TABLE IF EXISTS `tbl_activity`;
CREATE TABLE `tbl_activity`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `start_date` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `end_date` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `cost` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_activity
-- ----------------------------
INSERT INTO `tbl_activity` VALUES ('266c04e932f342c2b2c5636988f8cb9d', '40f6cdea0bd34aceb77492a1656d9fb3', '分页查询功能写完', '2023-01-13', '2023-01-16', '500', '写着简单，但是细节部分还是不够仔细', '2023-01-16', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL);
INSERT INTO `tbl_activity` VALUES ('48ad47f18bd64b5f8f909bf0a640c8d1', '06f5fc056eac41558a964f96daa7f27c', '测试02-分页查询功能', '2023-01-15', '2023-01-16', '0', '000', '2023-01-16', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL);
INSERT INTO `tbl_activity` VALUES ('50ca4de2397548ef8e9d128f0eada0eb', '06f5fc056eac41558a964f96daa7f27c', '英雄联盟S13', '2023-01-14', '2023-01-16', '600', '拉斯柯达就发了数控刀具发啦凯撒登记了卡机', '2023-01-16', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL);
INSERT INTO `tbl_activity` VALUES ('6526ebaec6564278b75de99065a65238', '06f5fc056eac41558a964f96daa7f27c', '修改功能模块_04', '2023-01-16', '2023-01-17', '60', '600_02', '2023-01-17', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-17 22-27-10', '40f6cdea0bd34aceb77492a1656d9fb3');
INSERT INTO `tbl_activity` VALUES ('86b53f5855b842dfa13f00f87b558373', '06f5fc056eac41558a964f96daa7f27c', 'CRM项目创建资金', '2023-01-11', '2023-01-31', '50000', '正则表达式一定要加^ $', '2023-01-13', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL);
INSERT INTO `tbl_activity` VALUES ('9175830355fb4461ae29d3e5cdbcc6bf', '06f5fc056eac41558a964f96daa7f27c', '测试111', '2022-11-27', '2022-12-28', '10', '零食', '2023-01-18', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL);
INSERT INTO `tbl_activity` VALUES ('b0e511aada4b4ab5800f6c9eeabd80f5', '06f5fc056eac41558a964f96daa7f27c', '日历插件', '2023-01-13', '2023-01-14', '60', '日历插件中文乱码，没有解决，懒的解决', '2023-01-14', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL);
INSERT INTO `tbl_activity` VALUES ('cc15bba5103b4dbab953d46810734d4a', '06f5fc056eac41558a964f96daa7f27c', 'CRM项目创建资金', '2023-01-11', '2023-01-31', '20000', '加强学习能力，想自己想要的东西迈出一小步', '2023-01-13', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL);
INSERT INTO `tbl_activity` VALUES ('ff33ffa34e424e2f88da676951c8958e', '40f6cdea0bd34aceb77492a1656d9fb3', '市场删除测试', '2023-01-16', '2023-01-17', '50000', '', '2023-01-17', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-29 00:01:19', '40f6cdea0bd34aceb77492a1656d9fb3');

-- ----------------------------
-- Table structure for tbl_activity_remark
-- ----------------------------
DROP TABLE IF EXISTS `tbl_activity_remark`;
CREATE TABLE `tbl_activity_remark`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `note_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '0??ʾδ?޸ģ?1??ʾ???޸',
  `activity_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_activity_remark
-- ----------------------------
INSERT INTO `tbl_activity_remark` VALUES ('076bfc418c664d33af4a7252624a94f1', '备注', '2023-01-28 23:57:01', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL, '0', '43bbcd954a3b4b6d82ba5e2bef37e684');
INSERT INTO `tbl_activity_remark` VALUES ('1c7866bca9b144e6b472ea0b1db0e48c', '测试001', '2023-01-29 01:06:31', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-29 01:06:51', '40f6cdea0bd34aceb77492a1656d9fb3', '1', NULL);
INSERT INTO `tbl_activity_remark` VALUES ('283666d4456f4a2ab340d5935266f91e', '呜呜呜', '2023-01-23 14:19:39', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 15:18:20', '40f6cdea0bd34aceb77492a1656d9fb3', '1', NULL);
INSERT INTO `tbl_activity_remark` VALUES ('31269b441b4a4b3fb3cfb31936f9e386', '阿萨德', '2023-01-21 17:15:22', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL, '0', '81897db694b7403fbe274ee8ac2921c9');
INSERT INTO `tbl_activity_remark` VALUES ('43145a87f95a44ba8699a11d59b2b883', '222', '2023-01-21 19:48:00', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL, '0', '266c04e932f342c2b2c5636988f8cb9d');
INSERT INTO `tbl_activity_remark` VALUES ('4a47c02c6daa4b6886bac5ba082e151e', '测试伤处', '2023-01-21 17:29:44', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL, '0', '81897db694b7403fbe274ee8ac2921c9');
INSERT INTO `tbl_activity_remark` VALUES ('59ad3d464ff144f9bee9b1cb81eb11f9', '修改', '2023-01-23 14:11:25', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 15:18:28', '40f6cdea0bd34aceb77492a1656d9fb3', '1', NULL);
INSERT INTO `tbl_activity_remark` VALUES ('5c521f95d5ee4418ab6a453a65619a0f', '备注测试', '2023-01-29 00:22:50', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL, '0', 'ff33ffa34e424e2f88da676951c8958e');
INSERT INTO `tbl_activity_remark` VALUES ('62586bd1386a4537a33789f03c1638de', '例子', '2023-01-21 17:21:10', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL, '0', 'c61952dc5a6545ddaddbcdaf776bc64a');
INSERT INTO `tbl_activity_remark` VALUES ('85e33e257d414134ad7821fec336b5ce', '111', '2023-01-21 19:47:37', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL, '0', '266c04e932f342c2b2c5636988f8cb9d');
INSERT INTO `tbl_activity_remark` VALUES ('86572047f20c4342ab46ae4ce36c0d2f', '阿斯顿发', '2023-01-22 00:19:29', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 15:19:42', '40f6cdea0bd34aceb77492a1656d9fb3', '1', NULL);
INSERT INTO `tbl_activity_remark` VALUES ('8d38b195738743318cf775ef6120a80a', '备注测试', '2023-01-28 23:58:05', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-28 23:58:18', '40f6cdea0bd34aceb77492a1656d9fb3', '1', NULL);
INSERT INTO `tbl_activity_remark` VALUES ('b6fb7d49b3c44a908e74059ac056f915', 'ASDF SDAF', '2023-01-23 14:33:10', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 15:17:14', '40f6cdea0bd34aceb77492a1656d9fb3', '1', NULL);
INSERT INTO `tbl_activity_remark` VALUES ('fcccdfffc520460fa4d534d98c195fd7', '备注', '2023-01-21 17:43:48', '40f6cdea0bd34aceb77492a1656d9fb3', NULL, NULL, '0', 'ff33ffa34e424e2f88da676951c8958e');

-- ----------------------------
-- Table structure for tbl_clue
-- ----------------------------
DROP TABLE IF EXISTS `tbl_clue`;
CREATE TABLE `tbl_clue`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fullname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `appellation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `owner` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `company` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `job` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `mphone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `state` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `contact_summary` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `next_contact_time` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_clue
-- ----------------------------
INSERT INTO `tbl_clue` VALUES ('059bb99b90184fc0b89950091ca4b663', '秋水', '59795c49896947e1ab61b7312bd0597c', '06f5fc056eac41558a964f96daa7f27c', '秋水公司', '本科', '2429294126@qq.com', '63868999', 'http://127.0.0.1:8080/crm', '13090960888', '9e6d6e15232549af853e22e703f3e015', '72f13af8f5d34134b5b3f42c5d477510', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-24 14:17:23', NULL, NULL, '无', '无', '2023-1-24', '下抱抱');

-- ----------------------------
-- Table structure for tbl_clue_activity_relation
-- ----------------------------
DROP TABLE IF EXISTS `tbl_clue_activity_relation`;
CREATE TABLE `tbl_clue_activity_relation`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clue_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `activity_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for tbl_clue_remark
-- ----------------------------
DROP TABLE IF EXISTS `tbl_clue_remark`;
CREATE TABLE `tbl_clue_remark`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `note_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `clue_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_clue_remark
-- ----------------------------
INSERT INTO `tbl_clue_remark` VALUES ('283666d4456f4a2ab340d5935266f91p', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '059bb99b90184fc0b89950091ca4b663');
INSERT INTO `tbl_clue_remark` VALUES ('283666d4456f4a2ab340d5935266f969', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '059bb99b90184fc0b89950091ca4b663');

-- ----------------------------
-- Table structure for tbl_contacts
-- ----------------------------
DROP TABLE IF EXISTS `tbl_contacts`;
CREATE TABLE `tbl_contacts`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `customer_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `fullname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `appellation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `mphone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `job` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `contact_summary` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `next_contact_time` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_contacts
-- ----------------------------
INSERT INTO `tbl_contacts` VALUES ('07ce3c1474d44658b577131fc4121750', '40f6cdea0bd34aceb77492a1656d9fb3', '72f13af8f5d34134b5b3f42c5d477510', '405ff3d01e594dc49cd0f7fce9f14a8e', '秋水', '59795c49896947e1ab61b7312bd0597c', '2429294126@qq.com', '13090960888', '本科', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-29 00:23:50', NULL, NULL, '无', '无', '2023-1-24', '下抱抱');
INSERT INTO `tbl_contacts` VALUES ('1216fdfe57784c199c05e9583f383ec7', '40f6cdea0bd34aceb77492a1656d9fb3', '72f13af8f5d34134b5b3f42c5d477510', '405ff3d01e594dc49cd0f7fce9f14a8e', '秋水', '59795c49896947e1ab61b7312bd0597c', '2429294126@qq.com', '13090960888', '本科', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-28 23:04:02', NULL, NULL, '无', '无', '2023-1-24', '下抱抱');
INSERT INTO `tbl_contacts` VALUES ('1f9f46145a544f3eb29cec28199c6aa1', '40f6cdea0bd34aceb77492a1656d9fb3', '72f13af8f5d34134b5b3f42c5d477510', '405ff3d01e594dc49cd0f7fce9f14a8e', '秋水', '59795c49896947e1ab61b7312bd0597c', '2429294126@qq.com', '13090960888', '本科', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-28 23:22:29', NULL, NULL, '无', '无', '2023-1-24', '下抱抱');
INSERT INTO `tbl_contacts` VALUES ('44869e2c1fea45559bce7047ccc2d44d', '40f6cdea0bd34aceb77492a1656d9fb3', '72f13af8f5d34134b5b3f42c5d477510', 'b25c77ea393f4cb3ba846eb181406ac9', '秋水', '59795c49896947e1ab61b7312bd0597c', '2429294126@qq.com', '13090960888', '本科', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-28 22:55:12', NULL, NULL, '无', '无', '2023-1-24', '下抱抱');
INSERT INTO `tbl_contacts` VALUES ('8d2716cd6bbf4525bf1786ce89821a7a', '40f6cdea0bd34aceb77492a1656d9fb3', '72f13af8f5d34134b5b3f42c5d477510', 'fd5748320ffc4c31b8019fb0b29959c4', '秋水', '59795c49896947e1ab61b7312bd0597c', '2429294126@qq.com', '13090960888', '本科', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-27 00:19:40', NULL, NULL, '无', '无', '2023-1-24', '下抱抱');
INSERT INTO `tbl_contacts` VALUES ('9dac4385bae146878a11edf863b50635', '40f6cdea0bd34aceb77492a1656d9fb3', '72f13af8f5d34134b5b3f42c5d477510', '405ff3d01e594dc49cd0f7fce9f14a8e', '秋水', '59795c49896947e1ab61b7312bd0597c', '2429294126@qq.com', '13090960888', '本科', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-29 00:02:39', NULL, NULL, '无', '无', '2023-1-24', '下抱抱');
INSERT INTO `tbl_contacts` VALUES ('de91c43b05504e60beb6e540bd90b812', '40f6cdea0bd34aceb77492a1656d9fb3', '72f13af8f5d34134b5b3f42c5d477510', '405ff3d01e594dc49cd0f7fce9f14a8e', '秋水', '59795c49896947e1ab61b7312bd0597c', '2429294126@qq.com', '13090960888', '本科', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-27 00:15:48', NULL, NULL, '无', '无', '2023-1-24', '下抱抱');

-- ----------------------------
-- Table structure for tbl_contacts_activity_relation
-- ----------------------------
DROP TABLE IF EXISTS `tbl_contacts_activity_relation`;
CREATE TABLE `tbl_contacts_activity_relation`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contacts_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `activity_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_contacts_activity_relation
-- ----------------------------
INSERT INTO `tbl_contacts_activity_relation` VALUES ('315e4204324c4d46ba2bd5da18698b97', '07ce3c1474d44658b577131fc4121750', '266c04e932f342c2b2c5636988f8cb9d');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('4a330a483d184041b5fb16da1ba04cb9', '8d2716cd6bbf4525bf1786ce89821a7a', '43bbcd954a3b4b6d82ba5e2bef37e684');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('56f4074c03df470fa5068daa61ffec37', '1f9f46145a544f3eb29cec28199c6aa1', '6526ebaec6564278b75de99065a65238');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('6d9f67e70ad5495ab5574d4d3e7ae422', '1f9f46145a544f3eb29cec28199c6aa1', '43bbcd954a3b4b6d82ba5e2bef37e684');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('73de8521974c499c8f5c905ed5822450', '1f9f46145a544f3eb29cec28199c6aa1', '266c04e932f342c2b2c5636988f8cb9d');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('7d8275b40aa54bde81f3860bfc42bc9e', '9dac4385bae146878a11edf863b50635', '48ad47f18bd64b5f8f909bf0a640c8d1');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('7fb39f79cbea4071b914430cee378bef', 'de91c43b05504e60beb6e540bd90b812', '43bbcd954a3b4b6d82ba5e2bef37e684');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('7ff1d2279e374d86bdc94ffad0c74ed1', '9dac4385bae146878a11edf863b50635', '266c04e932f342c2b2c5636988f8cb9d');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('967921170d8844e1b4bcf1a2358103a3', '1f9f46145a544f3eb29cec28199c6aa1', '50ca4de2397548ef8e9d128f0eada0eb');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('99d7be59b86148f79d83363cd3055a80', '07ce3c1474d44658b577131fc4121750', '48ad47f18bd64b5f8f909bf0a640c8d1');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('be0313a15e9a419284d60997ae80cc8b', '07ce3c1474d44658b577131fc4121750', '6526ebaec6564278b75de99065a65238');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('cacbb85193644c929d36f4b68461ef2e', '07ce3c1474d44658b577131fc4121750', '50ca4de2397548ef8e9d128f0eada0eb');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('d3a724922f944c03b246852ab6e75e28', '1f9f46145a544f3eb29cec28199c6aa1', '86b53f5855b842dfa13f00f87b558373');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('e5f15b32ddcd436e94cfd4ee25e0b9a4', '8d2716cd6bbf4525bf1786ce89821a7a', '266c04e932f342c2b2c5636988f8cb9d');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('e8a61c7a18b7477d84674ffca4245420', 'de91c43b05504e60beb6e540bd90b812', '6526ebaec6564278b75de99065a65238');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('f3648055b7a44bcb95ad93fe63b37793', '9dac4385bae146878a11edf863b50635', '50ca4de2397548ef8e9d128f0eada0eb');
INSERT INTO `tbl_contacts_activity_relation` VALUES ('f81ecedaace943e689a360991f159068', '1f9f46145a544f3eb29cec28199c6aa1', '48ad47f18bd64b5f8f909bf0a640c8d1');

-- ----------------------------
-- Table structure for tbl_contacts_remark
-- ----------------------------
DROP TABLE IF EXISTS `tbl_contacts_remark`;
CREATE TABLE `tbl_contacts_remark`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `note_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `contacts_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_contacts_remark
-- ----------------------------
INSERT INTO `tbl_contacts_remark` VALUES ('094816fa269c4c728f37df51c9ba1e2f', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '07ce3c1474d44658b577131fc4121750');
INSERT INTO `tbl_contacts_remark` VALUES ('0aca56194ec94556a5213f258b7f6590', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '1216fdfe57784c199c05e9583f383ec7');
INSERT INTO `tbl_contacts_remark` VALUES ('0f00f87fe075443e96f7e3dfc8e78fb5', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', 'de91c43b05504e60beb6e540bd90b812');
INSERT INTO `tbl_contacts_remark` VALUES ('1ba5d99384a247469b39ea8767d4034f', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '44869e2c1fea45559bce7047ccc2d44d');
INSERT INTO `tbl_contacts_remark` VALUES ('3ff84ef333af4d619c24e069021481b1', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '1f9f46145a544f3eb29cec28199c6aa1');
INSERT INTO `tbl_contacts_remark` VALUES ('40920af6814845948245d79bbaa4d16d', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '1216fdfe57784c199c05e9583f383ec7');
INSERT INTO `tbl_contacts_remark` VALUES ('47598bb8403d4cf7a40918ac76af7f6e', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '8d2716cd6bbf4525bf1786ce89821a7a');
INSERT INTO `tbl_contacts_remark` VALUES ('5dde96735ee94a2f82f198e593a54372', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '9dac4385bae146878a11edf863b50635');
INSERT INTO `tbl_contacts_remark` VALUES ('73803292142b47e7a79fe0fd99a73f08', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '8d2716cd6bbf4525bf1786ce89821a7a');
INSERT INTO `tbl_contacts_remark` VALUES ('88ba860688a1492ebd30675084b08840', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '9dac4385bae146878a11edf863b50635');
INSERT INTO `tbl_contacts_remark` VALUES ('93f23ddf981b4bdea1796efec44c24ae', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '1f9f46145a544f3eb29cec28199c6aa1');
INSERT INTO `tbl_contacts_remark` VALUES ('a8cbf400386e4167a66b287d82cfe446', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '07ce3c1474d44658b577131fc4121750');
INSERT INTO `tbl_contacts_remark` VALUES ('e86b02192e92411c9a3bcb6d6660cb88', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '44869e2c1fea45559bce7047ccc2d44d');
INSERT INTO `tbl_contacts_remark` VALUES ('f3eba2c24ed94596914368b0468da978', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', 'de91c43b05504e60beb6e540bd90b812');

-- ----------------------------
-- Table structure for tbl_customer
-- ----------------------------
DROP TABLE IF EXISTS `tbl_customer`;
CREATE TABLE `tbl_customer`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `contact_summary` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `next_contact_time` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_customer
-- ----------------------------
INSERT INTO `tbl_customer` VALUES ('405ff3d01e594dc49cd0f7fce9f14a8e', '40f6cdea0bd34aceb77492a1656d9fb3', '秋水公司', 'http://127.0.0.1:8080/crm', '63868999', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-27 00:15:48', NULL, NULL, '无', '2023-1-24', '无', '下抱抱');
INSERT INTO `tbl_customer` VALUES ('b25c77ea393f4cb3ba846eb181406ac9', '40f6cdea0bd34aceb77492a1656d9fb3', '动力节点', 'http://127.0.0.1:8080/crm', '63868999', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-28 22:55:12', NULL, NULL, '无', '2023-1-24', '无', '下抱抱');

-- ----------------------------
-- Table structure for tbl_customer_remark
-- ----------------------------
DROP TABLE IF EXISTS `tbl_customer_remark`;
CREATE TABLE `tbl_customer_remark`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `note_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `customer_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_customer_remark
-- ----------------------------
INSERT INTO `tbl_customer_remark` VALUES ('0b4592ddb6a14a07a4a1bc9dd9e5e44a', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '405ff3d01e594dc49cd0f7fce9f14a8e');
INSERT INTO `tbl_customer_remark` VALUES ('2343cd3871e940c4bd0580bed7635e01', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '405ff3d01e594dc49cd0f7fce9f14a8e');
INSERT INTO `tbl_customer_remark` VALUES ('30993e5feb1d4dad8eeb6fde9b3a062b', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '405ff3d01e594dc49cd0f7fce9f14a8e');
INSERT INTO `tbl_customer_remark` VALUES ('5a80c82e28cf4ff3a5aa2e66a4f349de', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '405ff3d01e594dc49cd0f7fce9f14a8e');
INSERT INTO `tbl_customer_remark` VALUES ('6307f01694e34bd499adb5e1771047e0', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '405ff3d01e594dc49cd0f7fce9f14a8e');
INSERT INTO `tbl_customer_remark` VALUES ('6b3d6661ca304a178cc2b7dec51be879', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', 'b25c77ea393f4cb3ba846eb181406ac9');
INSERT INTO `tbl_customer_remark` VALUES ('6bb91493440147619ae6ed203b2792a0', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '405ff3d01e594dc49cd0f7fce9f14a8e');
INSERT INTO `tbl_customer_remark` VALUES ('6d43a135e9d7477e8375c7d8c2f8cbf4', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', 'b25c77ea393f4cb3ba846eb181406ac9');
INSERT INTO `tbl_customer_remark` VALUES ('78e072dcf2854b528824e8ac03847f74', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '405ff3d01e594dc49cd0f7fce9f14a8e');
INSERT INTO `tbl_customer_remark` VALUES ('a3e3b5105443479c91acdbe78ee7ef99', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', 'fd5748320ffc4c31b8019fb0b29959c4');
INSERT INTO `tbl_customer_remark` VALUES ('a884b9cc661b4739ab70f3cdb3356b18', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '405ff3d01e594dc49cd0f7fce9f14a8e');
INSERT INTO `tbl_customer_remark` VALUES ('ca25d82d1d9241a5a1506d4e3251cf7f', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', 'fd5748320ffc4c31b8019fb0b29959c4');
INSERT INTO `tbl_customer_remark` VALUES ('cb6eb83702b04129a6fbd4a1ad6dce53', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '405ff3d01e594dc49cd0f7fce9f14a8e');
INSERT INTO `tbl_customer_remark` VALUES ('d70d8b2f247d468ea086db473953df92', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '405ff3d01e594dc49cd0f7fce9f14a8e');

-- ----------------------------
-- Table structure for tbl_dic_type
-- ----------------------------
DROP TABLE IF EXISTS `tbl_dic_type`;
CREATE TABLE `tbl_dic_type`  (
  `code` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '编码是主键，不能为空，不能含有中文。',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`code`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_dic_type
-- ----------------------------
INSERT INTO `tbl_dic_type` VALUES ('appellation', '称呼', '');
INSERT INTO `tbl_dic_type` VALUES ('clueState', '线索状态', '');
INSERT INTO `tbl_dic_type` VALUES ('returnPriority', '回访优先级', '');
INSERT INTO `tbl_dic_type` VALUES ('returnState', '回访状态', '');
INSERT INTO `tbl_dic_type` VALUES ('source', '来源', '');
INSERT INTO `tbl_dic_type` VALUES ('stage', '阶段', '');
INSERT INTO `tbl_dic_type` VALUES ('transactionType', '交易类型', '');

-- ----------------------------
-- Table structure for tbl_dic_value
-- ----------------------------
DROP TABLE IF EXISTS `tbl_dic_value`;
CREATE TABLE `tbl_dic_value`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '主键，采用UUID',
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '不能为空，并且要求同一个字典类型下字典值不能重复，具有唯一性。',
  `text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '可以为空',
  `order_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '可以为空，但不为空的时候，要求必须是正整数',
  `type_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '外键',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_dic_value
-- ----------------------------
INSERT INTO `tbl_dic_value` VALUES ('06e3cbdf10a44eca8511dddfc6896c55', '虚假线索', '虚假线索', '4', 'clueState');
INSERT INTO `tbl_dic_value` VALUES ('0fe33840c6d84bf78df55d49b169a894', '销售邮件', '销售邮件', '8', 'source');
INSERT INTO `tbl_dic_value` VALUES ('12302fd42bd349c1bb768b19600e6b20', '交易会', '交易会', '11', 'source');
INSERT INTO `tbl_dic_value` VALUES ('1615f0bb3e604552a86cde9a2ad45bea', '最高', '最高', '2', 'returnPriority');
INSERT INTO `tbl_dic_value` VALUES ('176039d2a90e4b1a81c5ab8707268636', '教授', '教授', '5', 'appellation');
INSERT INTO `tbl_dic_value` VALUES ('1e0bd307e6ee425599327447f8387285', '将来联系', '将来联系', '2', 'clueState');
INSERT INTO `tbl_dic_value` VALUES ('2173663b40b949ce928db92607b5fe57', '丢失线索', '丢失线索', '5', 'clueState');
INSERT INTO `tbl_dic_value` VALUES ('2876690b7e744333b7f1867102f91153', '未启动', '未启动', '1', 'returnState');
INSERT INTO `tbl_dic_value` VALUES ('29805c804dd94974b568cfc9017b2e4c', '成交', '成交', '7', 'stage');
INSERT INTO `tbl_dic_value` VALUES ('310e6a49bd8a4962b3f95a1d92eb76f4', '试图联系', '试图联系', '1', 'clueState');
INSERT INTO `tbl_dic_value` VALUES ('31539e7ed8c848fc913e1c2c93d76fd1', '博士', '博士', '4', 'appellation');
INSERT INTO `tbl_dic_value` VALUES ('37ef211719134b009e10b7108194cf46', '资质审查', '资质审查', '1', 'stage');
INSERT INTO `tbl_dic_value` VALUES ('391807b5324d4f16bd58c882750ee632', '丢失的线索', '丢失的线索', '8', 'stage');
INSERT INTO `tbl_dic_value` VALUES ('3a39605d67da48f2a3ef52e19d243953', '聊天', '聊天', '14', 'source');
INSERT INTO `tbl_dic_value` VALUES ('474ab93e2e114816abf3ffc596b19131', '低', '低', '3', 'returnPriority');
INSERT INTO `tbl_dic_value` VALUES ('48512bfed26145d4a38d3616e2d2cf79', '广告', '广告', '1', 'source');
INSERT INTO `tbl_dic_value` VALUES ('4d03a42898684135809d380597ed3268', '合作伙伴研讨会', '合作伙伴研讨会', '9', 'source');
INSERT INTO `tbl_dic_value` VALUES ('59795c49896947e1ab61b7312bd0597c', '先生', '先生', '1', 'appellation');
INSERT INTO `tbl_dic_value` VALUES ('5c6e9e10ca414bd499c07b886f86202a', '高', '高', '1', 'returnPriority');
INSERT INTO `tbl_dic_value` VALUES ('67165c27076e4c8599f42de57850e39c', '夫人', '夫人', '2', 'appellation');
INSERT INTO `tbl_dic_value` VALUES ('68a1b1e814d5497a999b8f1298ace62b', '因竞争丢失关闭', '因竞争丢失关闭', '9', 'stage');
INSERT INTO `tbl_dic_value` VALUES ('6b86f215e69f4dbd8a2daa22efccf0cf', 'web调研', 'web调研', '13', 'source');
INSERT INTO `tbl_dic_value` VALUES ('72f13af8f5d34134b5b3f42c5d477510', '合作伙伴', '合作伙伴', '6', 'source');
INSERT INTO `tbl_dic_value` VALUES ('7c07db3146794c60bf975749952176df', '未联系', '未联系', '6', 'clueState');
INSERT INTO `tbl_dic_value` VALUES ('86c56aca9eef49058145ec20d5466c17', '内部研讨会', '内部研讨会', '10', 'source');
INSERT INTO `tbl_dic_value` VALUES ('9095bda1f9c34f098d5b92fb870eba17', '进行中', '进行中', '3', 'returnState');
INSERT INTO `tbl_dic_value` VALUES ('954b410341e7433faa468d3c4f7cf0d2', '已有业务', '已有业务', '1', 'transactionType');
INSERT INTO `tbl_dic_value` VALUES ('966170ead6fa481284b7d21f90364984', '已联系', '已联系', '3', 'clueState');
INSERT INTO `tbl_dic_value` VALUES ('96b03f65dec748caa3f0b6284b19ef2f', '推迟', '推迟', '2', 'returnState');
INSERT INTO `tbl_dic_value` VALUES ('97d1128f70294f0aac49e996ced28c8a', '新业务', '新业务', '2', 'transactionType');
INSERT INTO `tbl_dic_value` VALUES ('9ca96290352c40688de6596596565c12', '完成', '完成', '4', 'returnState');
INSERT INTO `tbl_dic_value` VALUES ('9e6d6e15232549af853e22e703f3e015', '需要条件', '需要条件', '7', 'clueState');
INSERT INTO `tbl_dic_value` VALUES ('9ff57750fac04f15b10ce1bbb5bb8bab', '需求分析', '需求分析', '2', 'stage');
INSERT INTO `tbl_dic_value` VALUES ('a70dc4b4523040c696f4421462be8b2f', '等待某人', '等待某人', '5', 'returnState');
INSERT INTO `tbl_dic_value` VALUES ('a83e75ced129421dbf11fab1f05cf8b4', '推销电话', '推销电话', '2', 'source');
INSERT INTO `tbl_dic_value` VALUES ('ab8472aab5de4ae9b388b2f1409441c1', '常规', '常规', '5', 'returnPriority');
INSERT INTO `tbl_dic_value` VALUES ('ab8c2a3dc05f4e3dbc7a0405f721b040', '提案/报价', '提案/报价', '5', 'stage');
INSERT INTO `tbl_dic_value` VALUES ('b924d911426f4bc5ae3876038bc7e0ad', 'web下载', 'web下载', '12', 'source');
INSERT INTO `tbl_dic_value` VALUES ('c13ad8f9e2f74d5aa84697bb243be3bb', '价值建议', '价值建议', '3', 'stage');
INSERT INTO `tbl_dic_value` VALUES ('c83c0be184bc40708fd7b361b6f36345', '最低', '最低', '4', 'returnPriority');
INSERT INTO `tbl_dic_value` VALUES ('db867ea866bc44678ac20c8a4a8bfefb', '员工介绍', '员工介绍', '3', 'source');
INSERT INTO `tbl_dic_value` VALUES ('e44be1d99158476e8e44778ed36f4355', '确定决策者', '确定决策者', '4', 'stage');
INSERT INTO `tbl_dic_value` VALUES ('e5f383d2622b4fc0959f4fe131dafc80', '女士', '女士', '3', 'appellation');
INSERT INTO `tbl_dic_value` VALUES ('e81577d9458f4e4192a44650a3a3692b', '谈判/复审', '谈判/复审', '6', 'stage');
INSERT INTO `tbl_dic_value` VALUES ('fb65d7fdb9c6483db02713e6bc05dd19', '在线商场', '在线商场', '5', 'source');
INSERT INTO `tbl_dic_value` VALUES ('fd677cc3b5d047d994e16f6ece4d3d45', '公开媒介', '公开媒介', '7', 'source');
INSERT INTO `tbl_dic_value` VALUES ('ff802a03ccea4ded8731427055681d48', '外部介绍', '外部介绍', '4', 'source');

-- ----------------------------
-- Table structure for tbl_tran
-- ----------------------------
DROP TABLE IF EXISTS `tbl_tran`;
CREATE TABLE `tbl_tran`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `money` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `expected_date` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `customer_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `stage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `activity_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `contacts_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `contact_summary` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `next_contact_time` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_tran
-- ----------------------------
INSERT INTO `tbl_tran` VALUES ('01472729a8d1442e9ed8bfc7aacefbe8', '06f5fc056eac41558a964f96daa7f27c', '600', 'impart', '2023-1-31', '405ff3d01e594dc49cd0f7fce9f14a8e', 'e44be1d99158476e8e44778ed36f4355', '97d1128f70294f0aac49e996ced28c8a', '12302fd42bd349c1bb768b19600e6b20', 'b0e511aada4b4ab5800f6c9eeabd80f5', '8d2716cd6bbf4525bf1786ce89821a7a', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-29 00:03:30', NULL, NULL, '秋水公司', '秋水公司', '2023-1-31');
INSERT INTO `tbl_tran` VALUES ('084e347b48b34d5f88d0f951512a6d98', '40f6cdea0bd34aceb77492a1656d9fb3', '200', '秋水公司-无命', '2023-1-27', 'fd5748320ffc4c31b8019fb0b29959c4', '9ff57750fac04f15b10ce1bbb5bb8bab', NULL, NULL, '50ca4de2397548ef8e9d128f0eada0eb', '8d2716cd6bbf4525bf1786ce89821a7a', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-27 00:19:40', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_tran` VALUES ('2f10965c3e42400f96faab399f366175', '06f5fc056eac41558a964f96daa7f27c', '500', '交易测试001', '2023-1-28', '405ff3d01e594dc49cd0f7fce9f14a8e', 'ab8c2a3dc05f4e3dbc7a0405f721b040', '97d1128f70294f0aac49e996ced28c8a', '72f13af8f5d34134b5b3f42c5d477510', '50ca4de2397548ef8e9d128f0eada0eb', '8d2716cd6bbf4525bf1786ce89821a7a', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-28 15:37:33', NULL, NULL, '这是一场伟大的活动', '这是一场伟大的活动', '2023-1-31');
INSERT INTO `tbl_tran` VALUES ('34472e45090545c78b668a8a91c20ae7', '40f6cdea0bd34aceb77492a1656d9fb3', '500', '测试活动', '2023-1-22', 'b25c77ea393f4cb3ba846eb181406ac9', '29805c804dd94974b568cfc9017b2e4c', '954b410341e7433faa468d3c4f7cf0d2', '86c56aca9eef49058145ec20d5466c17', 'fca2443087f64bd9b4e77ce3c41d31b6', '8d2716cd6bbf4525bf1786ce89821a7a', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-29 00:04:57', NULL, NULL, '2023-1-22', '2023-1-22', '2023-1-22');
INSERT INTO `tbl_tran` VALUES ('59e94f500d2d406bb33ce1f6606836f6', '06f5fc056eac41558a964f96daa7f27c', '300', '市场活动', '2023-1-28', 'b25c77ea393f4cb3ba846eb181406ac9', '37ef211719134b009e10b7108194cf46', '954b410341e7433faa468d3c4f7cf0d2', '86c56aca9eef49058145ec20d5466c17', '43bbcd954a3b4b6d82ba5e2bef37e684', '8d2716cd6bbf4525bf1786ce89821a7a', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-28 23:23:32', NULL, NULL, '市场活动', '市场活动', '2023-1-28');
INSERT INTO `tbl_tran` VALUES ('78c3f1edd3cd47a988d9a0739df83ad8', '40f6cdea0bd34aceb77492a1656d9fb3', '500', '秋水公司-测试', '2023-1-29', '405ff3d01e594dc49cd0f7fce9f14a8e', '9ff57750fac04f15b10ce1bbb5bb8bab', NULL, NULL, 'activity', '07ce3c1474d44658b577131fc4121750', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-29 00:23:50', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_tran` VALUES ('93ab41fc745849819e78bf7b136a69ca', '40f6cdea0bd34aceb77492a1656d9fb3', '520', '秋水公司-测试002', '2023-1-28', '405ff3d01e594dc49cd0f7fce9f14a8e', '29805c804dd94974b568cfc9017b2e4c', NULL, NULL, 'activity', '1f9f46145a544f3eb29cec28199c6aa1', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-28 23:22:29', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_tran` VALUES ('a4902307d08e4fc5898953b63732caf3', '40f6cdea0bd34aceb77492a1656d9fb3', '500', '秋水公司-测试', '2023-1-29', '405ff3d01e594dc49cd0f7fce9f14a8e', 'e44be1d99158476e8e44778ed36f4355', NULL, NULL, 'activity', '9dac4385bae146878a11edf863b50635', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-29 00:02:39', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_tran` VALUES ('ebd6904141954f6cb6ac18c31b87c9f3', '06f5fc056eac41558a964f96daa7f27c', '500', 'imp交易', '2023-1-29', 'b25c77ea393f4cb3ba846eb181406ac9', '29805c804dd94974b568cfc9017b2e4c', '954b410341e7433faa468d3c4f7cf0d2', '72f13af8f5d34134b5b3f42c5d477510', '9175830355fb4461ae29d3e5cdbcc6bf', '8d2716cd6bbf4525bf1786ce89821a7a', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-29 00:25:04', NULL, NULL, 'imp交易', 'imp交易', '2023-1-31');

-- ----------------------------
-- Table structure for tbl_tran_history
-- ----------------------------
DROP TABLE IF EXISTS `tbl_tran_history`;
CREATE TABLE `tbl_tran_history`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `stage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `money` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `expected_date` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `tran_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_tran_history
-- ----------------------------
INSERT INTO `tbl_tran_history` VALUES ('28abd41905cf4b3e9482c51943107fea', '37ef211719134b009e10b7108194cf46', '300', '2023-1-28', '2023-01-28 23:23:32', '40f6cdea0bd34aceb77492a1656d9fb3', '59e94f500d2d406bb33ce1f6606836f6');
INSERT INTO `tbl_tran_history` VALUES ('48c6e39ec0134f039279a46ce47b6542', '29805c804dd94974b568cfc9017b2e4c', '500', '2023-1-29', '2023-01-29 00:25:04', '40f6cdea0bd34aceb77492a1656d9fb3', 'ebd6904141954f6cb6ac18c31b87c9f3');
INSERT INTO `tbl_tran_history` VALUES ('5b901f0ac3ea49b88a66dfda3109cf02', '29805c804dd94974b568cfc9017b2e4c', '500', '2023-1-22', '2023-01-29 00:04:57', '40f6cdea0bd34aceb77492a1656d9fb3', '34472e45090545c78b668a8a91c20ae7');
INSERT INTO `tbl_tran_history` VALUES ('8ad6430af33e457c993745020d5a8a80', '', '', '', '2023-01-28 22:55:34', '40f6cdea0bd34aceb77492a1656d9fb3', 'f904f36fd14f4db4a31003b80e29a8f9');
INSERT INTO `tbl_tran_history` VALUES ('ac0957a0b99c484fa8c51d18dea5ed07', 'ab8c2a3dc05f4e3dbc7a0405f721b040', '500', '2023-1-28', '2023-01-28 15:37:33', '40f6cdea0bd34aceb77492a1656d9fb3', '2f10965c3e42400f96faab399f366175');
INSERT INTO `tbl_tran_history` VALUES ('e6a94256aaa743ca87fb08d12771f732', 'e44be1d99158476e8e44778ed36f4355', '600', '2023-1-31', '2023-01-29 00:03:30', '40f6cdea0bd34aceb77492a1656d9fb3', '01472729a8d1442e9ed8bfc7aacefbe8');

-- ----------------------------
-- Table structure for tbl_tran_remark
-- ----------------------------
DROP TABLE IF EXISTS `tbl_tran_remark`;
CREATE TABLE `tbl_tran_remark`  (
  `id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `note_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `create_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_time` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `edit_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `tran_id` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_tran_remark
-- ----------------------------
INSERT INTO `tbl_tran_remark` VALUES ('0d65e772925142549b9a10e694e07fa3', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '93ab41fc745849819e78bf7b136a69ca');
INSERT INTO `tbl_tran_remark` VALUES ('75bf9adbcdd9476d87b059706e4f06af', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '427293cb6f7449628a1ee45ddd19a509');
INSERT INTO `tbl_tran_remark` VALUES ('782c0f3fe3a04587a0d0a60eb77a559b', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '427293cb6f7449628a1ee45ddd19a509');
INSERT INTO `tbl_tran_remark` VALUES ('78e7ca28ee634947b2a4e4bd84362b71', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '2f10965c3e42400f96faab399f366175');
INSERT INTO `tbl_tran_remark` VALUES ('80dc9ce594f04812bb4a85da9d3b1ce3', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '78c3f1edd3cd47a988d9a0739df83ad8');
INSERT INTO `tbl_tran_remark` VALUES ('870f4543ae2547359fcd4965c48303f6', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', 'c486657fc80c49d4a4beb0d4a0bdef14');
INSERT INTO `tbl_tran_remark` VALUES ('9dc46cc43b2649abae80653fe9f9a8f2', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '93ab41fc745849819e78bf7b136a69ca');
INSERT INTO `tbl_tran_remark` VALUES ('b66877dacfbd4762964fd6b08b9c9a06', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '2f10965c3e42400f96faab399f366175');
INSERT INTO `tbl_tran_remark` VALUES ('bbf769faeaa54cfcafeee5a86292676c', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', 'a4902307d08e4fc5898953b63732caf3');
INSERT INTO `tbl_tran_remark` VALUES ('be312114a41f42c798412d0159cb72b2', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', '78c3f1edd3cd47a988d9a0739df83ad8');
INSERT INTO `tbl_tran_remark` VALUES ('e167abb838c24e9691a2dfb35f05896f', '呜呜呜', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', 'a4902307d08e4fc5898953b63732caf3');
INSERT INTO `tbl_tran_remark` VALUES ('efcc6e4bbbf947f988030bfa0a366ca5', '这是一个测试备注001', '40f6cdea0bd34aceb77492a1656d9fb3', '2023-01-23 14:19:39', NULL, NULL, '0', 'c486657fc80c49d4a4beb0d4a0bdef14');

-- ----------------------------
-- Table structure for tbl_user
-- ----------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE `tbl_user`  (
  `id` char(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'uuid\r\n            ',
  `login_act` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `login_pwd` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码不能采用明文存储，采用密文，MD5加密之后的数据',
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `expire_time` char(19) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '失效时间为空的时候表示永不失效，失效时间为2018-10-10 10:10:10，则表示在该时间之前该账户可用。',
  `lock_state` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '锁定状态为空时表示启用，为0时表示锁定，为1时表示启用。',
  `deptno` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `allow_ips` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '允许访问的IP为空时表示IP地址永不受限，允许访问的IP可以是一个，也可以是多个，当多个IP地址的时候，采用半角逗号分隔。允许IP是192.168.100.2，表示该用户只能在IP地址为192.168.100.2的机器上使用。',
  `createTime` char(19) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `create_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `edit_time` char(19) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `edit_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_user
-- ----------------------------
INSERT INTO `tbl_user` VALUES ('06f5fc056eac41558a964f96daa7f27c', 'ls', '李四', '123', 'ls@163.com', '2055-11-27 21:50:05', '1', 'A001', '192.168.1.1,0:0:0:0:0:0:0:1', '2018-11-22 12:11:40', '李四', NULL, NULL);
INSERT INTO `tbl_user` VALUES ('40f6cdea0bd34aceb77492a1656d9fb3', 'zs', '张三', '123', 'zs@qq.com', '2055-11-30 23:50:55', '1', 'A001', '192.168.1.1,192.168.1.2,127.0.0.1,0:0:0:0:0:0:0:1', '2018-11-22 11:37:34', '张三', NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
