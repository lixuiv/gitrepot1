package com.qiushui.crm.commons.constants;

public class Constans {
    public static final String RETURN_OBJECT_LOGIN_SUCCESS="1";
    public static final String RETURN_OBJECT_LOGIN_FAILURE="0";
    public static final String SESSION_LOGIN_INF="loginUser";
    public static final String SESSION_ACTIVITY_USERS="userList";

    public static final String RETURN_OBJECT_SUCCESS="1";
    public static final String RETURN_OBJECT_FAILURE="0";
}
