package crm.utils.test;

public class JdkTest {
    public static void main(String[] args) {
        System.out.println("HelloWorld");
    }
}
